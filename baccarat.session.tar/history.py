print(banker_bettor.bet_amount)
print(banker_bettor.)
print(banker_bettor.stake_history)
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')

##---(Tue Dec  8 16:22:50 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')

##---(Wed Dec  9 14:41:27 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
dir()
print(temp)
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
walk
from Baccarat1 import percentChange
dir()
percentChange(0,7)
percentChange(7,0)
percentChange(5,8)
percentChange(0,8)
percentChange(1,8)
walk
walkHistory
percentChange(1, walkHistory[9])
percentChange(walkHistory[10], walkHistory[19])
percentChange(walkHistory[20], walkHistory[29])
percentChange(walkHistory[30], walkHistory[39])
percentChange(walkHistory[40], walkHistory[49])
len(walkHistory)
percentChange(walkHistory[50], walkHistory[59])
percentChange(walkHistory[60], walkHistory[69])
percentChange(walkHistory[70], walkHistory[79])
percentChange(walkHistory[70], walkHistory[-1])
percentChange(min([1, walkHistory[40]], walkHistory[49])
)
min([1, walkHistory[40]])
min([-1, walkHistory[40]])
percentChange(min([1, walkHistory[40]]), walkHistory[49])
percentChange(min([-1, walkHistory[40]]), walkHistory[49])
percentChange(min([-1, walkHistory[0]]), walkHistory[9])
percentChange(min([-1, walkHistory[10]]), walkHistory[19])
percentChange(min([-1, walkHistory[20]]), walkHistory[29])
percentChange(min([-1, walkHistory[30]]), walkHistory[39])
percentChange(min([-1, walkHistory[40]]), walkHistory[49])
percentChange(min([-1, walkHistory[50]]), walkHistory[59])
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
percentChange(min([-1, walkHistory[0]]), walkHistory[9])
percentChange(min([-1, walkHistory[10]]), walkHistory[19])
percentChange(min([-1, walkHistory[20]]), walkHistory[29])
percentChange( walkHistory[10], walkHistory[19])
percentChange( walkHistory[20], walkHistory[29])
percentChange( walkHistory[20], walkHistory[24])
percentChange( walkHistory[30], walkHistory[39])
percentChange( walkHistory[40], walkHistory[49])
percentChange( walkHistory[50], walkHistory[59])
percentChange( walkHistory[60], walkHistory[69])
percentChange( walkHistory[70], walkHistory[-1])
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
walkHistory[-10] - walkHistory[-1]
walkHistory[-10] 
walkHistory[-1]
walkHistory[0] - walkHistory[-1]
walkHistory[0]
walkHistory[-1] - walkHistory[0]
walkHistory[-1] - walkHistory[-10]
dir(math)
def fibonacci(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else: return fibonacci(n-1) + fibonacci(n-2)
    
fibonacci(6)
fibonacci(7)
fibonacci(8)
fibonacci(9)
fibonacci(10)
fibonacci(111)
fibonacci(11)
fibonacci(12)
fibonacci(13)
fibonacci(14)
clear
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
fibonacci[13]
fibonacci(13)
fibonacci(9)
fibonacci(11)
fibonacci(12)
fibonacci(10)
min(60, fibonacci(9)
)
min(60, fibonacci(11))
min(60, fibonacci(10))
for b in range(2, 12)
for b in range(2, 12):
    print('Bet {}'.format(min(fibonacci(b), 60))
    )
    )
for b in range(2, 12):
    print(b)
    )
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')