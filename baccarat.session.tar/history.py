runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/baccarat.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
# *** Spyder Python Console History Log ***
oc2 = Outcome('ferd', 3)
oc1 == oc2
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/baccarat.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
oc1 = Outcome('ferd', 3)
oc2 = Outcome('ferd', 3)
oc1 == oc2
print(oc1)
print(str(oc1))
str(oc1)
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/baccarat.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
oc1 = Outcome('ferd', 3)
str(oc1)
dir()
str(oc1)
print(oc1)
oc1
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/CasinoCards.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/testable.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')

##---(Fri Oct 16 11:25:18 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/baccarat.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
dir()
from baccarat import Outcome
zero= Outcome("0",35)
zero
print(zero)
b = frozenset([zero])
b
print(b)
map(str, b)
print(map(str, b))
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/baccarat.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')

##---(Fri Oct 16 12:15:12 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/baccarat.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/temp.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/baccarat.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
Bin?
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/baccarat.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/CasinoCards.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Roulette/roulette.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Roulette')

##---(Mon Oct 26 09:54:27 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')

##---(Fri Nov  6 08:59:03 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
print(scorecard)
scorecard.count('D')
scorecard.count('B')
scorecard.count('P')
scorecard.count('p')
scorecard.count('T')
33/80
print(scorecard[-5:])
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
scorecard.count('D')
scorecard.count('T')
scorecard.count('p')
scorecard.count('P')
scorecard.count('B')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
scorecard.count('D')
scorecard.count('T')
scorecard.count('P')
scorecard.count('p')
scorecard.count('B')
file?
help(file)
help(tell)
help(file.tell)
tell?
print(scorecard)
scorecard.count('T')
scorecard.count('D')
scorecard.count('p')
scorecard.count('P')
scorecard.count('B')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
print(currentBet)
repr(currentBet)
print(playerBet)
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
print(currentBet)
print(currentBet.amount)
file.close
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
43 * 25
43 * 5
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
49 * 5
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
print(currentBet.outcome)
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
from pylab import *
plot(stakeHistory)
show()
dir()
clear

##---(Sat Nov  7 22:00:09 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
from pylab import plot
plot(scorecard)
from pylab import *
plot(scorecard)

##---(Sat Nov  7 22:02:10 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
from pylab import *
plot(scorecard)
plot(stakeHistory)
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
print(temp)
temp = []
len(temp)
del(temp)
dir()