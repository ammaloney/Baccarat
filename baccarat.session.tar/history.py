runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
# *** Spyder Python Console History Log ***
len(temp)
1+2
1-2+3
1-2-3+4
1-2-3-4+5
-1+2+3
len(temp)
print(temp)
-1+2-3-4+5
_+1+2
_+1-2-3-4-5
_-1+2+3
_+1-2+3
_+1+2
_-1-2-3-4-5
_-1+2-3+4
_+1-2+3
_-1+2+3
_-1+2-3-4-5
_-1-2-3+4-5
_+1-2+3
_+1-2-3-4+5
_+1+2
_+1-2+3
_-1+2-3+4
_-1-2+3+4
_-1+2+3
_-1+2-3
print(temp)
+1-2+3
_+1-2-3-4-5
_+1+2
_-1-2-3+4-5
_-1-2+3+4
_+1+2
_-1+2-3-4+5
_-1+2+3
_+1+2
_-1+2-3+4
_-1-2+3+4
_+1-2-3-4-5
_+1-2+3
_-1+2-3+4
_+1-2-3+4
_-1-2+3-4+5
scorecard[:40].count('B')
scorecard[40:].count('B')
scorecard[40:50].count('B')
scorecard[40:60].count('B')
scorecard[60:].count('B')
scorecard[20:40].count('B')
scorecard[20:40].count('P')
plot(stakeHistory)
plt.plot(stakeHistory)
scorecard[:20].count('B')
scorecard[20:40].count('B')
scorecard[40:60].count('B')
scorecard[60:].count('B')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
scorecard[60:].count('B')
scorecard[50:].count('B')
scorecard[:20].count('B')
scorecard[20:40].count('B')
scorecard[40:60].count('B')
scorecard[60:].count('B')
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
scorecard[:20].count('B')
scorecard[20:40].count('B')
scorecard[40:60].count('B')
scorecard[60:].count('B')
scorecard[:50].count('B')
scorecard[50:].count('B')
scorecard[:50].count('P')
scorecard[:50].count('p')
scorecard[:50].count('B')
scorecard[50:].count('P')
scorecard[:50].count('P')
scorecard[:50].count('p')
scorecard[60:].count('B')
scorecard[60:].count('P')
scorecard[60:].count('p')

##---(Sun Dec  6 12:04:37 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
print(walkHistory)
print(len(walkHistory))
print(percentChange(walkHistory[-6:], walkHistory[-1])
)
print(percentChange(walkHistory[-6], walkHistory[-1])
)
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')
banker_bettor
print(banker_bettor)
print(banker_bettor.bet_on)
print(banker_bettor.stake)
print(banker_bettor.bet_amount)
print(banker_bettor.)
print(banker_bettor.stake_history)
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')

##---(Tue Dec  8 16:22:50 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')

##---(Wed Dec  9 14:41:27 2015)---
runfile('/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat/Baccarat1.py', wdir='/Volumes/Macintosh HD 2/Developer/DevPython/Baccarat')